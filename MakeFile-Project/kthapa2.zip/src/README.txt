This is a readme file.

There are 4 java classes which need to be compiled using Java 1.8 JRE. 
Make sure you have java 1.8 installed on your computer. 

The project also has a makefile which you can run on terminal.

To run the makefile, use below statement...

make

To compile and run the program manually, you need to execute the following commands...

javac FakeMakeExecutable.java

java FakeMakeExecutable input.txt

This will compile all the files and run the program 